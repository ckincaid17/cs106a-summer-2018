/*
 * File: AsciiFigure.java
 * --------------------
 * Draws a figure with SIZE number of lines, where each line contains    
 * 8 more stars than the line before it. Lines are padded with
 * forward and backward slashes.
 */

import acm.program.*;
 
public class AsciiFigure extends ConsoleProgram {
    private static final int SIZE = 5;           // number of lines
    private static final int STAR_INCREMENT = 8; // stars added/line
    
    public void run() {
        int maxLineWidth = STAR_INCREMENT * (SIZE - 1);
        for (int line = 0; line < SIZE; line++) {
            int numStarsOnLine = STAR_INCREMENT * line;
            int numSlashes = (maxLineWidth - numStarsOnLine) / 2;
            for (int i = 0; i < numSlashes; i++) {
                print("/");
            }
            for (int i = 0; i < numStarsOnLine; i++) {
                print("*");
            }
            for (int i = 0; i < numSlashes; i++) {
                print("\\");
            }
            println();
        }
    }
    
}

