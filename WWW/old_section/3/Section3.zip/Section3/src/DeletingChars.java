/*
 * File: DeletingChars.java
 * --------------------
 * Remove all instances of a particular character in a string.
 */

import java.io.*;
import java.util.*;

import acm.program.*;

public class DeletingChars extends ConsoleProgram {

	public void run() {
		String str = "This is a test";
		println(removeAllOccurrences(str, 't'));
	}


	private String removeAllOccurrences(String str, char ch) {
		String result = "";
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) != ch) {
				result += str.charAt(i);
			}
		}
		return result;
	}





}

