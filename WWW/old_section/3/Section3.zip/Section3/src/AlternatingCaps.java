/*
 * File: AlternatingCaps.java
 * --------------------
 * Converts a string to alternating capital letters.
 */

import java.io.*;
import java.util.*;

import acm.program.*;

public class AlternatingCaps extends ConsoleProgram {

	public void run() {
		String str = "This is a test";
		println(altCaps(str));
	}


	private String altCaps(String str) {
		String result = "";
		int counter = 0;
		for(int i = 0; i < str.length(); i++) {
			if (Character.isLetter(str.charAt(i))) counter++;
				
			if ((counter % 2) == 0) {
				result += Character.toUpperCase(str.charAt(i));
			}else{
				result += Character.toLowerCase(str.charAt(i));
			}
		}
		return result;
	}







}

