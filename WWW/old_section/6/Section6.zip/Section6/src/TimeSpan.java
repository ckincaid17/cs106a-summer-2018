// A TimeSpan object represents duration of time in hours and minutes.
public class TimeSpan {
    private int hours;
    private int minutes;

    // Constructs a time span with the given # of hours and minutes.
    public TimeSpan(int initialHours, int initialMinutes) {
        hours = 0;
        minutes = 0;
        add(initialHours, initialMinutes);
    }

    // Adds given hours/minutes to time span, wrapping hours if req’d.
    public void add(int hr, int mn) {
        hours += hr;
        minutes += mn;
        if (minutes >= 60) {
            minutes -= 60;   // convert 60 min --> 1 hour
            hours++;
        }
    }

    // Returns the hours represented by this time span.
    public double getHours() {
        return hours;
    }

    // Returns the minutes represented by this time span.
    public double getMinutes() {
        return minutes;
    }

    // Returns the total hours represented by this time span,
    // such as 7.75 for 7 hours, 45 minutes.
    public double getTotalHours() {
        return hours + minutes / 60.0;
    }

    // Returns a text representation of time span, such as "7h45m".
    public String toString() {
        return hours + "h" + minutes + "m";
    }
}
