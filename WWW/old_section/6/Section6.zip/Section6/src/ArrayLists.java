/* File: CountNames.java
 * ---------------------
 * This program reads a list of names from the user and lists out
 * how many times each name appeared in the list.
 */

import acm.program.*;
import java.util.*;

public class ArrayLists extends ConsoleProgram {

	public void run() {
		return;
	}

	private void mirror(ArrayList<String> list) {    
		for (int i = list.size() - 1; i >= 0; i--) {        
			list.add(list.get(i));    
		}
	}


	public void removeEvenLength(ArrayList<String> list) {
		for (int i = list.size() - 1; i >= 0; i--) {
			if (list.get(i).length() % 2 == 0) {
				list.remove(i);
			}
		}
	}

	private void switchPairs(ArrayList<String> list) {
		for (int i = 0; i < list.size() - 1; i += 2) {
			String first = list.remove(i);
			list.add(i + 1, first);
		}
	}




}
