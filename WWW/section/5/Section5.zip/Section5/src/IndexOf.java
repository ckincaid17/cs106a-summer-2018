import acm.program.*;
import acm.graphics.*;
import acm.util.*;

public class IndexOf extends ConsoleProgram {

    public void run() {
    	int[] list = {0, 5, 6, 8, 9};
    	println("Index of 6 is " + indexOf(list, 6));
    }
    
    private int indexOf(int[] list, int target) {
        for (int i = 0; i < list.length; i++) {
            if (list[i] == target){
                return i;
            }
        }
        return -1;
    }

}
