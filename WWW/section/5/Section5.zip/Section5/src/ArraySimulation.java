import acm.program.*;
import acm.graphics.*;
import acm.util.*;

public class ArraySimulation extends ConsoleProgram {

	public void run(){
	
		int[] arr1 = {10, 8, 9, 5, 5};
		int[] arr2 = {12, 11, 10, 10, 8, 7};
		mystery(arr1);
		mystery(arr2);

	}
	public void mystery(int[] nums) {
	    for (int i = 0; i < nums.length - 1; i++) {
	         if (nums[i] > nums[i + 1]) {
	             nums[i + 1]++;
	         }
	     }
	 }


}