import acm.program.*;
import acm.graphics.*;
import acm.util.*;

public class Collapse extends ConsoleProgram {

    public void run() {
    	int[] list = {7, 2, 8, 9, 4, 13, 7, 1, 9, 10};
    	int[] collapsedList = collapse(list);
    }
    
    public int[] collapse(int[] a) {
        int[] result = new int[a.length / 2 + a.length % 2];
        for (int i = 0; i < result.length - a.length % 2; i++) {
            result[i] = a[2 * i] + a[2 * i + 1];
        }
        if (a.length % 2 == 1) {
            result[result.length - 1] = a[a.length - 1];
        }
        return result;
    }



}