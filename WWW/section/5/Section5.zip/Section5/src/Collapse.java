import acm.program.*;
import acm.graphics.*;
import acm.util.*;

public class Collapse extends ConsoleProgram {

    public void run() {
    	int[] list = {7, 2, 8, 9, 4, 13, 7, 1, 9, 10};
    	int[] collapsedList = collapse(list);
    }
    
    public int[] collapse(int[] list) {
        int[] result = new int[list.length / 2 + list.length % 2];
        for (int i = 0; i < result.length - list.length % 2; i++) {
            result[i] = list[2 * i] + list[2 * i + 1];
        }
        if (list.length % 2 == 1) {
            result[result.length - 1] = list[list.length - 1];
        }
        return result;
    }



}