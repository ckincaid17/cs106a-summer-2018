import acm.program.*;
import acm.graphics.*;
import acm.util.*;

public class NumUnique extends ConsoleProgram {

    public void run() {
    	int[] list = {5, 7, 7, 7, 22, 22, 23, 35, 35, 40, 40, 40};
    	println("List has " + numUnique(list) + "unique values");
    }
    
    private int numUnique(int[] list) {
        if (list.length == 0) {
            return 0;
        }

        int count = 1;
        for (int i = 1; i < list.length; i++) {
            if (list[i] != list[i - 1]) {
                count++;
            }
        }
        return count;
    }


}