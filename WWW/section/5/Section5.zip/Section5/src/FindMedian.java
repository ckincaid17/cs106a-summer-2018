import acm.program.*;
import acm.graphics.*;
import acm.util.*;

public class FindMedian extends ConsoleProgram {

	public void run() {
		int[] list = {5, 7, 7, 7, 22, 22, 23, 35, 35, 40, 40, 40};
		println("Median is " + findMedian(list));
	}

	private static final int MAX_TEMP = 100;   // max possible temperature

	// Given a list of an odd number of temperatures, returns median temperature.
	private int findMedian(int[] temps) {
		double halfTheEntries = temps.length / 2.0;
		int[] histogram = histogramFor(temps);
		int cumulativeTotal = 0;
		for (int i = 0; i <= MAX_TEMP; i++) {
			cumulativeTotal += histogram[i];
			if (cumulativeTotal >= halfTheEntries)
				return i;
		}
		return 0;  // can't get here, but Java requires us to return a value
	}

	// Given a list of temperatures, returns a histogram of those temperatures.  
	// Histogram is an array whose ith element is the number of temps of exactly i.
	private int[] histogramFor(int[] temps) {
		int[] result = new int[MAX_TEMP + 1];
		for (int temp: temps) {
			result[temp]++;
		}
		return result;
	}



}