import acm.program.*;

import java.util.Arrays;

import acm.graphics.*;
import acm.util.*;

public class Banish extends ConsoleProgram {

    public void run() {
	    	String[] a1 = {"a", "c", "a", "z", "a", "a", "p", "j", "w"};
	    	String[] a2 = {"a", "p", "j"};
	    	banish(a1, a2);
	    	print(Arrays.toString(a1));
    }
    
    public void banish(String[] a1, String[] a2) {
        for (int i = 0; i < a1.length; i++) {
            boolean found = false;   // see whether a1[i] is contained in a2
            for (int j = 0; j < a2.length && !found; j++) {
                if (a1[i].equals(a2[j])) {
                    found = true;
                }
            }
            if (found) {   // shift all elements of a1 left by 1
                for (int j = i + 1; j < a1.length; j++) {
                    a1[j - 1] = a1[j];
                }
                a1[a1.length - 1] = "";
                i--;   // so that we won't skip an index
            }
        }
    }



}