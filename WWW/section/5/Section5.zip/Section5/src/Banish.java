import acm.program.*;
import acm.graphics.*;
import acm.util.*;

public class Banish extends ConsoleProgram {

    public void run() {
    	int[] a1 = {42, 3, 42, 11, 42, 42, 17, 0, 2222, 4, 9, 1};
    	int[] a2 = {42, 2222, 9};
    	banish(a1, a2);

    }
    
    public void banish(int[] a1, int[] a2) {
        for (int i = 0; i < a1.length; i++) {
            boolean found = false;   // see whether a1[i] is contained in a2
            for (int j = 0; j < a2.length && !found; j++) {
                if (a1[i] == a2[j]) {
                    found = true;
                }
            }
            if (found) {   // shift all elements of a1 left by 1
                for (int j = i + 1; j < a1.length; j++) {
                    a1[j - 1] = a1[j];
                }
                a1[a1.length - 1] = 0;
                i--;   // so that we won't skip an index
            }
        }
    }



}