/*
 * File: Commas.java
 * --------------------
 * Adds commas in the right places to numeric strings.
 */

import java.io.*;
import java.util.*;

import acm.program.*;

public class Commas extends ConsoleProgram {

	public void run() {
		String digits = "123456789";
		println(addCommasToNumericString(digits));
	}


	private String addCommasToNumericString(String digits) {
		String result = "";
		int len = digits.length();
		int nDigits = 0;
		for (int i = len - 1; i >= 0; i--) {
			result = digits.charAt(i) + result;
			nDigits++;
			if (((nDigits % 3) == 0) && (i > 0)) {
				result = "," + result;
			}
		}
		return result;
	}




}

