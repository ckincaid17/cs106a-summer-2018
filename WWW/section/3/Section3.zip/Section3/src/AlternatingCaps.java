/*
 * File: AlternatingCaps.java
 * --------------------
 * Converts a string to alternating capital letters.
 */

import java.io.*;
import java.util.*;

import acm.program.*;

public class AlternatingCaps extends ConsoleProgram {

	public void run() {
		String str = "CS106A rocks my socks!";
		println(altCaps(str));
	}


	private String altCaps(String str) {
		String result = "";
		int counter = 0;
		for(int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (Character.isLetter(ch)) counter++;
				
			if ((counter % 2) == 0) {
				result += Character.toUpperCase(ch);
			} else {
				result += Character.toLowerCase(ch);
			}
		}
		return result;
	}







}

