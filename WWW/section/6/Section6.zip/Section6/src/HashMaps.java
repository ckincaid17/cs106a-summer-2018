/* File: CountNames.java
 * ---------------------
 * This program reads a list of names from the user and lists out
 * how many times each name appeared in the list.
 */

import acm.program.*;
import java.util.*;

public class HashMaps extends ConsoleProgram {

	public void run() {
		return;
	}

	private HashMap<String, Integer> intersect(
			HashMap<String, Integer> map1, HashMap<String, Integer> map2) {
		HashMap<String, Integer> result = new HashMap<String, Integer>();
		for (String key : map1.keySet()) {
			int value = map1.get(key);
			if (map2.containsKey(key) && value == map2.get(key)) {
				result.put(key, value);
			}
		}
		return result;
	}
	
	private HashMap<String, Integer> reverse(HashMap<Integer, String> map) {
	    HashMap<String, Integer> result = new HashMap<String, Integer>();
	    for (int key : map.keySet()) {
	        String value = map.get(key);
	        result.put(value, key);
	    }
	    return result;
	}


}
