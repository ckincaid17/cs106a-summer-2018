/*
 * File: Airplane.java
 * ---------------------------
 * This program implements the Airplane class used by the Paper Plane
 * Airport in Airport.java.
 */

public class Airplane {

	private boolean airborne;

	public Airplane() {
		foldInHalf();
		foldWings();
		this.airborne = false;
	}

	public boolean isAirborne() {
		return airborne;
	}

	public void takeOff() {
		System.out.println("Airplane log: dispatching plane");
		this.airborne = true;
	}

	private void foldInHalf() {
		System.out.println("Airplane log: folded plane in half!");
	}

	private void foldWings() {
		System.out.println("Airplane log: folded plane wings!");
	}
}
