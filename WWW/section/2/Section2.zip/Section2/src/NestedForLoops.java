/*
 * File: NestedForLoops.java
 * --------------------
 * This program prints out a 10-row top-down pyramid of asterisks.
 */

import acm.program.*;

public class NestedForLoops extends ConsoleProgram {
	public void run() {
		for (int i = 1; i <= 10; i++) {        
		    for (int j = 1; j <= 10 - i; j++) {            
		        print(" ");    
		    }    
		    for (int j = 1; j <= 2 * i - 1; j++) {        
		        print("*");    
		    }    
		    println();
		}
	}
}