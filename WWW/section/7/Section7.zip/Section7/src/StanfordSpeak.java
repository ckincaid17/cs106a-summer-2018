import acm.program.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

/* Allows the user to type in a phrase, then translates the phrase to its Stanford
 * abbreviation.
 */
public class StanfordSpeak extends Program {
    /* Private constants */
    private static final int TEXT_FIELD_WIDTH = 20;

    /* Private fields */
    private JTextField input;
    private JLabel label;

    public void init() {
        setSize(500, 100);
        add(new JLabel("Enter a phrase: "), NORTH);
        input = new JTextField(TEXT_FIELD_WIDTH);
        input.setActionCommand("Translate");
        input.addActionListener(this);
        add(input, NORTH);
        add(new JButton("Translate"), NORTH);
  
        label = new JLabel("");      // label for displaying "Stanford Speak" later
        label.setFont(new Font("Courier", Font.BOLD, 40));
        add(label, SOUTH);
        addActionListeners();
    }

    /* Triggered when the user clicks "Translate" or presses ENTER. */
    public void actionPerformed(ActionEvent event) {
        String phrase = input.getText();
        String abbrev = createStanfordAbbreviation(phrase);
        label.setText(abbrev);
    }
    
    /* Translates phrase by individually translating each word. */
    private String createStanfordAbbreviation(String phrase) {
        String result = "";
        Scanner scan = new Scanner(phrase);
        while (scan.hasNext()) {
            String word = scan.next();
            result += abbreviateWord(word);
        }
        return result;
    }

    /* We said you can assume that this method is provided. The methods 
     below are included for completeness. */

    private String abbreviateWord(String word) {
        word = word.toLowerCase();
        int vp = findFirstVowel(word);
        if (vp == -1) return word;  // return same word if no vowels
        String result = word.substring(0, vp + 1);
        if (vp + 1 < word.length() && isSonorant(word.charAt(vp + 1)))
            result += word.charAt(vp + 1);
        // convert the first letter in the word to uppercase
        result = Character.toUpperCase(result.charAt(0)) + result.substring(1);
        return result;
    }

    private int findFirstVowel(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (isEnglishVowel(str.charAt(i)))
                return i;
        }
        return -1;
    }

    private boolean isEnglishVowel(char ch) {
        return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
    }

    private boolean isSonorant(char ch) {
        return ch == 'm' || ch == 'n';
    }
}
