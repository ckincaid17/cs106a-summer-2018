import acm.program.*;

public class ExpandableArrayTest extends ConsoleProgram {
	public void run() {
		ExpandableArray myList = new ExpandableArray();
		myList.set(14, "Lebron");
		myList.set(21,  "Serena");
		
		String value = (String) myList.get(14);
		
		if (value != null) {
			println("Got value: " + value);
		} else {
			println("Doesn't exist");
		}
	}
}
