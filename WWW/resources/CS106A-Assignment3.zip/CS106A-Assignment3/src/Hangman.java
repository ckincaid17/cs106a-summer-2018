// TODO: comment this file

import acm.program.*;
import acm.util.*;
import java.io.*;    // for File
import java.util.*;  // for Scanner

public class Hangman extends HangmanProgram {
	
	public void run() {
		// TODO: write this method
	}
	
	// TODO: comment this method
	private void intro() {
		// TODO: write this method
	}
	
	// TODO: comment this method
	private int playOneGame(String secretWord) {
		// TODO: write this method
		return 0;
	}
	
	
	// TODO: comment this method
	private String createHint(String secretWord, String guessedLetters) {
		// TODO: write this method
		return "";
	}
	
	// TODO: comment this method
	private char readGuess(String guessedLetters) {
		// TODO: write this method
		return '?';
	}
	
	// TODO: comment this method
	private void displayHangman(int guessCount) {
		// TODO: write this method
	}
	
	// TODO: comment this method
	private void stats(int gamesCount, int gamesWon, int best) {
		// TODO: write this method
	}
	
	// TODO: comment this method
	private String getRandomWord(String filename) {
		// TODO: write this method
		return "";
	}
}
