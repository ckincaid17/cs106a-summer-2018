// TODO: comment this program

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Artistry2 extends GraphicsProgram {
	public void run() {
		// TODO: finish this program		
	}
}
