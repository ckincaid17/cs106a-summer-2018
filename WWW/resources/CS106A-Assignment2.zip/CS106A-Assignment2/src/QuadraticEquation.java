// TODO: comment this program

import acm.program.*;

public class QuadraticEquation extends ConsoleProgram {
	public void run() {
		// TODO: finish this program
	}
}
