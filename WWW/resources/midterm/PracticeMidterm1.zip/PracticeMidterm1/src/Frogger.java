/*
 * File: Frogger.java
 * ------------------------
 * This program solves the Frogger problem from the practice midterm,
 * where the frog jumps vertically based on the position of mouse
 * clicks.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;
import java.awt.event.*;

public class Frogger extends GraphicsProgram {
	private GImage frog;
	
	public void run() {
		// Just for testing purposes; try setting different window sizes here.
		setSize(300, 220);
		
		frog = new GImage("res/frog.gif");
		double fx = (getWidth() - frog.getWidth()) / 2;
		double fy = getHeight() - frog.getHeight();
		add(frog, fx, fy);
	}

	public void mouseClicked(MouseEvent event) {
		double mouseY = event.getY();
		double frogTop = frog.getY();
		double frogHeight = frog.getHeight();
		double frogBottom = frogTop + frogHeight;
		if (mouseY < frogTop && frogTop >= frogHeight) {
			frog.move(0, -frogHeight);
		} else if (mouseY > frogBottom && frogBottom + frogHeight <= getHeight()) {
			frog.move(0, frogHeight);
		}
	}
}
