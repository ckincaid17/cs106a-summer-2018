/* File: Problem2
 * --------------
 * This file contains the code and expressions you must
 * evaluate on problem 2.  Note that, because this is a
 * GraphicsProgram, System.out.println prints text in the
 * bottom of the Eclipse window.
 */
import acm.program.*;
import acm.graphics.*;
import java.awt.*;

public class Problem2 extends GraphicsProgram {
	public void run() {
		String s = 1 + (2 + "B") + 'A';
		System.out.println("i) " + s);

		boolean b = 11 / 2 > 5 || 5 % 2 == 1;
		System.out.println("ii) " + b);

		String s2 = (char)('B' + 2) + "" + 4 + 27 / 3;
		System.out.println("iii) " + s2);

		double d = 21 / 2.0 + 3 % 4 - 23 / 2;
		System.out.println("iv) " + d);

		boolean b2 = !(3 / 2 < 1.5) && (4 > 5 || 2 % 3 == 0);
		System.out.println("v) " + b2);

		// Graphics trace
		int num2 = 13;
		int num1 = 9;
		int width = mystery1(num2, num1);
		int height = mystery1(5, num2*3);
		GRect rect = new GRect(0, 0, width*3, height);
		rect.setFilled(true);
		rect.setColor(Color.BLUE);
		mystery2(rect, num1);
		add(rect);
		System.out.println("x = " + rect.getX());
		System.out.println("y = " + rect.getY());
		System.out.println("width = " + rect.getWidth());
		System.out.println("height = " + rect.getHeight());
		System.out.println("color = " + rect.getColor());
	}

	private int mystery1(int num1, int num2) {
		num2 += 3;
		String str = "Hello " + num1;
		int num3 = num2 - str.length();
		return num3;
	}

	private void mystery2(GRect otherRect, int num2) {
		otherRect.setLocation(num2, num2);
		otherRect.setColor(Color.RED);
	}



}
