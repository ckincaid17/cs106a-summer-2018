/* File: ReplaceMentions
 * ---------------------
 * This is the code for 5a) and 5b) This program reads in a file and replaces
 * all @mentions with their expanded names.  An @mention is defined as an '@'
 * followed by any number of camel-cased names; e.g.
 * @NickPaulTroccoli or @MartyTheBombStepp.
 * 
 * When it encounters an @mention, this program should remove the '@' and
 * insert spaces between all names.  Additionally, it should abbreviate the
 * last name to just be the first initial followed by a period.  For instance:
 * 
 * @NickPaulTroccoli -> Nick Paul T.
 * @MartyTheBombStep -> Marty The Bomb S.
 * 
 * A special case is if the @mention has only 1 name, e.g. @Nick.  In this case,
 * You should replace it with the entire first name, e.g. Nick.
 */

import acm.program.*;
import java.io.*;
import java.util.*;

public class ReplaceMentions extends ConsoleProgram {
	
	// Part (b)
	public void run() {
		String filename = promptUserForFile("Enter filename: ", "res");
		try {
			Scanner s = new Scanner(new File(filename));
			
			// We can assume only 1 line, so we need only 1 scanner
			while (s.hasNext()) {
				print(replaceMention(s.next()) + " ");
			}
			s.close();
		} catch (IOException e) {
			println("File could not be read.");
		}
	}

	// Part (a)
	private String replaceMention(String str) {		
		if (str.length() == 0 || str.charAt(0) != '@') return str;

		// If only one name, just remove the '@'
		if (countUppercaseLetters(str) == 1) {
			return str.substring(1);
		}
		
		// Build up a new string with the mention expanded
		String newStr = "";
		for (int i = 1; i < str.length(); i++) {
			char ch = str.charAt(i);
			
			// If it's upper case, check if it's the last uppercase letter
			if (Character.isUpperCase(ch)) {
				
				// If it's the last name, print out initial + '.' and return
				if (countUppercaseLetters(str.substring(i+1)) == 0) {
					newStr += " " + ch + ".";
					return newStr;
				} else {
					/* Otherwise, it's the start of a new middle name,
					 * so add a space before.
					 */
					newStr += " " + ch;
				}
			} else {
				// Otherwise, append the character as normal
				newStr += ch;
			}
		}

		return newStr;
	}
	
	// A helper method that returns the number of uppercase letters in the given string.
	private int countUppercaseLetters(String str) {
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			if (Character.isUpperCase(str.charAt(i))) {
				count++;
			}
		}
		
		return count;
	}
}
