/* File: MovieKiosk
 * ---------------------
 * This program continually prompts users for movie names they are attending,
 * or "" to stop prompting.  At the end, the program prints out the names of
 * all movies the user is buying tickets for ("Movie1 and Movie2 and Movie3")
 * and the total price of all tickets.
 * 
 * For every movie purchase, there is a 10% chance the user receives a
 * "movie voucher" good towards their next purchase only.  This voucher is for
 * a random integer amount $5-25.  
 */

import acm.program.*;
import acm.util.*;

public class MovieKiosk extends ConsoleProgram {
	public void run() {
		String movieNames = "";
		double total = 0;
		int voucher = 0;
		
		String movieName = readLine("Movie name: ");
		while (movieName.length() > 0) {
			int numTickets = readInt("# tickets: ");			
			double ticketPrice = readDouble("Ticket price: ");
			
			/* If the voucher doesn't cover the total cost, add
			 * the remaining balance to total.  Otherwise,
			 * the user owes nothing (the voucher covers it all) 
			 */
			if (voucher < ticketPrice * numTickets) {
				total += numTickets * ticketPrice - voucher;
			}
			voucher = 0;
				
			// Randomly award a voucher for the next purchase
			if (RandomGenerator.getInstance().nextBoolean(0.1)) {
				voucher = RandomGenerator.getInstance()
						.nextInt(5, 25);
				println("You've won a $" + voucher +
						" voucher for your next purchase!");
			}

			// Add the movie name to our string
			if (movieNames.equals("")) {
				movieNames = movieName;
			} else {
				movieNames += " and " + movieName;
			}
			println();
			
			movieName = readLine("Movie name: ");
		}

		println();
		if (!movieNames.equals("")) {
			println("Movies: " + movieNames);
			println("Total: $" + total);
		} else {
			println("Movies: None");
		}
	}
}
