/*
 * File: StrikerKarel.java
 * ---------------------
 * Karel scores a goal!
 */

import stanford.karel.*;

public class StrikerKarel extends SuperKarel {
	public void run() {
		// Karel stops upon reaching the goal, which is the only situation
		// when Karel can be blocked to the north, south, and east.
		while (leftIsClear() || rightIsClear() || frontIsClear()) {
			if (frontIsBlocked()) {
				findWallOpening();
			}
			dribble();
		}
	}

	/**
	 * Pre: Karel is facing east in some avenue and their front is blocked.
	 * Post: Karel is facing east in the same avenue and their front is clear.
	 */
	private void findWallOpening() {
		turnLeft();
		// Go as far north as possible
		while (frontIsClear()) {
			dribble();
		}
		turnAround();
		// Go south until there is an opening in the wall
		while (leftIsBlocked()) {
			dribble();
		}
		turnLeft();
	}

	// Less elegant but marginally more efficient implementation of the above
	private void findWallOpeningFast() {
		// Look for the opening to the north.
		turnLeft();
		while (frontIsClear() && rightIsBlocked()) {
			dribble();
		}
		// Did we finish that loop because we found an opening to the north?
		if (rightIsClear()) {
			turnRight();
		} else {
			// If not, look for the opening that must be to the south.
			turnAround();
			while (leftIsBlocked()) {
				dribble();
			}
			turnLeft();
		}
	}

	/**
	 * Pre: Karel is on top of a beeper, and Karel's front is clear.
	 * Post: Karel is on top of a beeper, having moved once in the direction
	 *       they were originally facing.
	 */
	private void dribble() {
			pickBeeper();
			move();
			putBeeper();
	}
}
