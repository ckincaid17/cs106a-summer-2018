/*
 * File: PollsterPanic.java
 * ---------------------
 * Graphics program, events
 */


import java.awt.Color;
import java.awt.event.MouseEvent;

import acm.graphics.GLabel;
import acm.graphics.GObject;
import acm.graphics.GRect;
import acm.program.GraphicsProgram;
import stanford.cs106.util.RandomGenerator;

public class PollsterPanic extends GraphicsProgram {
	
	private static final int N_ROWS = 3;
	private static final int N_COLS = 5;
	
	private static final int ZONE_WIDTH = 120;
	private static final int ZONE_HEIGHT = 150;
	
	private GLabel label;
	
	// Part A
	public void run() {
		for (int row = 0; row < N_ROWS; row++) {
			for (int col = 0; col < N_COLS; col++) {
				double x = col * ZONE_WIDTH;
				double y = row * ZONE_HEIGHT;
				GRect zone = new GRect(x, y, ZONE_WIDTH, ZONE_HEIGHT);
				if (RandomGenerator.getInstance().nextBoolean()) {
					zone.setColor(Color.BLUE);
					zone.setFilled(true);
					zone.setFillColor(Color.CYAN);
				} else {
					zone.setColor(Color.RED);
					zone.setFilled(true);
					zone.setFillColor(Color.PINK);
				}
				add(zone);
			}
		}
		label = new GLabel("Map created!");
		double mapEdgeX = ZONE_WIDTH * N_COLS;
		double openSpaceCenterX = mapEdgeX + (getWidth() - mapEdgeX) / 2; 
		double labelX = openSpaceCenterX - (label.getWidth()) / 2;
		// simplified labelX: (getWidth() + ZONE_WIDTH * N_COLS - label.getWidth()) / 2;
		double labelY = label.getAscent();
		add(label, labelX, labelY);
	}
		
	// Part B
	public void mouseClicked(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		
		GObject obj = getElementAt(x, y);
		String message = "";
		if (obj == null || obj == label) {
			message = "No zone selected";
		} else if (obj.getColor().equals(Color.BLUE)) {
			message = "Democrat zone";
		} else if (obj.getColor().equals(Color.RED)) {
			message = "Republican zone";
		}
		label.setText(message);
	}
}

