/*
 * File: Problem2B.java
 * ---------------------
 * Trace
 */

import acm.graphics.GOval;
import acm.program.*;

public class Problem2B extends ConsoleProgram {
	public void run() {
		int alexandria = 14;
		int ben = 18;
		alexandria = tinky(ben, alexandria);
		println(ben); // ii
		GOval cory = new GOval(19, 87, 19, 91);
		int deray = 66;
		winky(cory, deray);
		println(cory.getHeight()); // iii
		println(deray); // iv
		String elizabeth = "NSP";
		elizabeth.toLowerCase();
		println(elizabeth); // v
	}
	
	private int tinky(int alexandria, int ben) {
		alexandria /= 2;
		ben /= 2;
		println(alexandria);  // i
		return ben;
	}
	
	private void winky(GOval cory, int deray) {
		deray = 76;
		cory.setSize(19, 92);
		deray++;
	}
}
