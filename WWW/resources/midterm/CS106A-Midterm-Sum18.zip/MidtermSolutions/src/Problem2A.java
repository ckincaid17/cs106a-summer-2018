/*
 * File: Problem2A.java
 * ---------------------
 * Expression evaluation
 */

import acm.program.*;

public class Problem2A extends ConsoleProgram {
	public void run() {
		println((double)(16 / 5) * 10);
		println(Boolean.toString('D' - 'A' == '3'));
		println(2 + 5 + "M" + 2 * 5 + 2);
		println(200 + 19 % 10 - (42 / 10.0 / 2) * 100);
		println(Boolean.toString(!((false || 3 != 4) && !(7 / 2.0 < 3.5))));
	}
}

