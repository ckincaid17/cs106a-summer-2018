/*
 * File: MyCrosswordTrainer.java
 * ---------------------
 * Console program, text processing, file reading
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import acm.program.*;
import stanford.cs106.util.RandomGenerator;

public class MyCrosswordTrainer extends ConsoleProgram {
	private static final String FILENAME = "res/crossword.txt";

	// Part B
	public void run() {
		double revealChance = readDouble("Probability of revealing a letter? ");
		while (revealChance < 0 || revealChance > 1) {
			revealChance = readDouble("Enter a valid probability between 0 and 1: ");
		}
		try {
			Scanner input = new Scanner(new File(FILENAME));
			// input.nextInt() technically does not work but we'll allow it
			int numClues = Integer.parseInt(input.nextLine());
			int numCorrect = 0;
			for (int i = 0; i < numClues; i++) {
				String line = input.nextLine();
				int delimIndex = -1;
				for (int j = line.length() - 1; j >= 0; j--) {
					if (line.charAt(j) == '#') {
						delimIndex = j;
						break;
					}
				}
				String clue = line.substring(0, delimIndex);
				String answer = line.substring(delimIndex + 1);

				boolean success = testOneClue(clue, answer, revealChance);
				if (success) {
					println("Correct!");
					numCorrect++;
				} else {
					println("The answer was: " + answer);
				}
				println();
			}
			input.close();
			println("Percent correct: " + 100.0 * numCorrect / numClues + "%");
		} catch (FileNotFoundException e) {
			println(e);
		}
	}

	// Part A
	private boolean testOneClue(String clue, String answer, double revealChance) {
		println(clue);
		String answerLetters = "";
		for (int i = 0; i < answer.length(); i++) {
			if (RandomGenerator.getInstance().nextBoolean(revealChance)) {
				answerLetters += answer.charAt(i);
			} else {
				answerLetters += "-";
			}
		}
		println(answerLetters);
		String guess = readLine("Guess: ");
		return guess.equalsIgnoreCase(answer);
	}
}
