/*
 * CS 106A, Practice Midterm
 * 
 * This project may help you to test your answers to code-writing problems.
 * We strongly recommend that you do not write your initial answers in this
 * project, but instead write them out on paper and test them here afterward
 * for correctness, since that will be more similar to the real exam.
 */

import acm.program.*;
import acm.util.*;
import java.io.*;
import java.util.*;

public class PracticeMidterm extends ConsoleProgram {
	public void run() {
		printIntro();
		int answer = readInt("? ");

		while (answer != -1) {
			if (answer == 1) {
				p1_karel();
			} else if (answer == 2) {
				p2_expressionsAndStatements();
				p2_program();
			} else if (answer == 3) {
				p3_consolePrograms();
			} else if (answer == 4) {
				p4_graphicsPrograms();
			} else if (answer == 5) {
				p5_stringsCharactersAndFiles();
			}
			
			answer = readInt("Select the problem you would like to run: ");
		}
	}
	
	private void printIntro() {
		println("CS 106A Practice Midterm");
		println("=========================");
		println("Select the problem you would like to run (-1 to quit): ");
		println("\t 1) Karel the Robot");
		println("\t 2) Java expressions, statements and methods");
		println("\t 3) Console Programs");
		println("\t 4) Graphics Programs");
		println("\t 5) Strings, Characters and Files");
		println("\t -1) Quit");
		println("=========================");
	}

	private void p1_karel() {
		println("1. Karel the Robot");
		println("   - Run the separate InnerBorderKarel program for this one.");
		println();
	}

	private void p2_expressionsAndStatements() {
		println("1. Expressions and Statements");
		println(5.0 / 4 - 4 / 5);
		println(7 < 9 - 5 && 3 % 0 == 3);
		println("B" + 8 + 4);
		println();
	}

	private void p2_program() {
		int num1 = 2;
		int num2 = 13;
		println("The 1st number is: " + mystery(num1, 6));	
		println("The 2nd number is: " + mystery(num2 % 5, 1 + num1 * 2));
	}

	private int mystery(int num1, int num2) {
		num1 = unknown(num1, num2);
		num2 = unknown(num2, num1);
		return num2;
	}

	private int unknown(int num1, int num2) {
		int num3 = num1 + num2;
		num2 += num3 * 2;
		return num2;
	}

	// Defines the sentinel used to signal the end of the input for problem 3
	private static final int SENTINEL = 0;

	private void p3_consolePrograms() {
		println("3. ConsolePrograms");
		println("This program finds the two largest integers in a");
		println("list.  Enter values, one per line, using a "
				+ SENTINEL + " to");
		println("signal the end of the list.");

		int largest = -1;
		int secondLargest = -1;
		int input = readInt(" ? ");
		while (input != SENTINEL) {
			if (input > largest) {
				secondLargest = largest;
				largest = input;
			} else if (input > secondLargest) {
				secondLargest = input;
			}

			input = readInt(" ? ");
		}

		println("The largest value is " + largest);
		println("The second largest is " + secondLargest);
	}

	private void p4_graphicsPrograms() {
		println("4. GraphicsPrograms");
		println("   - Run the separate Frogger class for this one.");
		println();
	}

	private void p5_stringsCharactersAndFiles() {
		println("5. Strings, Characters and Files");
		println("a) removeDuplicates:");
		println("\"bookkeeper\" -> " + removeDuplicates("bookkeeper"));
		println("\"tresssssidder\" -> " + removeDuplicates("tresssssidder"));
		println("\"aaaAAA   bbbbBBBB    cccccCCC\" -> " + removeDuplicates("aaaAAA   bbbbBBBB    cccccCCC"));
		println("\"banana\" -> " + removeDuplicates("banana"));
		println("\"X\" -> " + removeDuplicates("X"));
		println("\"\" -> " + removeDuplicates(""));
		println();
		println("b) removeDuplicatesFromFile:");
		println("-------\nres/myinput1.txt\n-------");
		removeDuplicatesFromFile("res/myinput1.txt");
		println("-------\nres/myinput2.txt\n-------");
		removeDuplicatesFromFile("res/myinput2.txt");
		println();
	}

	private String removeDuplicates(String str) {
		String result = "";
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (i == 0 || ch != str.charAt(i - 1)) {
				result += ch;
			}
		}
		return result;
	}

	private void removeDuplicatesFromFile(String filename) {
		try {
			Scanner input = new Scanner(new File(filename));

	      // We need to read line by line to preserve line breaks
			while (input.hasNextLine()) {
				String line = input.nextLine();
				Scanner tokens = new Scanner(line);
				while (tokens.hasNext()) {
					String word = tokens.next();
					print(removeDuplicates(word) + " ");
				}
				println();
			}
			input.close();
		} catch (IOException ex) {
			println("file could not be read: " + ex);
		}
	}
}
