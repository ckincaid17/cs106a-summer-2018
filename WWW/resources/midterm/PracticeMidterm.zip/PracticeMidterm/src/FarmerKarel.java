/* File: FarmerKarel
 * ---------------
 * Karel must "farm" its world by, in each row, gathering up all of the crops
 * ("beepers") and putting them on the leftmost square of that row.  Karel
 * starts with infinite beepers in its beeper bag.
 * ---------------
 */

import stanford.karel.*;

public class FarmerKarel extends SuperKarel {
	public void run() {
		checkRow();
		while (leftIsClear()) {
			moveToNextRow();
			checkRow();
		}
	}

	/* Precondition: Karel is facing East with at least 1 row above it.
	 * Postcondition: Karel is facing East one row up.
	 */
	private void moveToNextRow() {
		turnLeft();
		move();
		turnRight();
	}

	/* Precondition: Karel is facing East at the beginning of a row.
	 * Postcondition: Karel is in the same position, but has put all
	 * of the beepers in the row on that square.
	 */
	private void checkRow() {
		if (frontIsClear()) {
			goToBeeper();
			while (beepersPresent()) {
				bringBeeperHome();
				goToBeeper();
			}
			turnAround();
			moveToWall();
			turnAround();
		}
	}

	/* Precondition: Karel is not facing a wall.
	 * Postcondition: Karel has moved until it reaches a beeper or a wall.
	 */
	private void goToBeeper() {
		move();
		while (frontIsClear() && noBeepersPresent()) {
			move();
		}
	}

	/* Precondition: Karel is standing on a beeper, facing East
	 * Postcondition: Karel is standing on the leftmost square of
	 * the same row, facing East, with the beeper now on that square.
	 */
	private void bringBeeperHome() {
		pickBeeper();
		turnAround();
		moveToWall();
		turnAround();
		putBeeper();
	}

	/* Precondition: NA
	 * Postcondition: Karel has moved straight until it reaches a wall.
	 */
	private void moveToWall() {
		while (frontIsClear()) {
			move();
		}
	}
}
