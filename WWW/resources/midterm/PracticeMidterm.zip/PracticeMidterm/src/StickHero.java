/* File: StickHero
 * ---------------
 * A program that animates StickHero across the screen horizontally.
 * If StickHero reaches the right edge of the screen, it wraps back
 * around to the left edge.  If the user clicks on StickHero, it toggles
 * between "double size" and "original size" while keeping the center
 * of the player the same.
 */
import acm.program.*;
import acm.graphics.*;
import java.awt.*;
import java.awt.event.*;

public class StickHero extends GraphicsProgram {	
	private boolean isOriginalSize;
	private GImage player;
	
	public void run() {
		isOriginalSize = true;
		player = new GImage("res/player.png");
		add(player, 0, getHeight() / 2.0 - player.getHeight() / 2.0);
		
		// Animate the player across the screen
		while (true) {
			player.move(5, 0);
			
			// If the player reaches the right edge, move to the left edge
			if (player.getX() + player.getWidth() >= getWidth()) {
				player.setLocation(0, getHeight() / 2.0 - 
						player.getHeight() / 2.0);
			}
			pause(30);
		}
	}
	
	public void mouseClicked(MouseEvent e) {
		GObject obj = getElementAt(e.getX(), e.getY());
		if (obj == player) {
			if (isOriginalSize) {
				// double the size while keeping the center the same
				player.setX(player.getX() - player.getWidth() / 2.0);
				player.setY(player.getY() - player.getHeight() / 2.0);
				player.setSize(2*player.getWidth(), 2*player.getHeight());
			} else {
				// half the size while keeping the center the same
				player.setX(player.getX() + player.getWidth() / 4.0);
				player.setY(player.getY() + player.getHeight() / 4.0);
				player.setSize(0.5*player.getWidth(), 
						0.5*player.getHeight());
			}
			isOriginalSize = !isOriginalSize;	// flip the boolean
		}
	}
}
