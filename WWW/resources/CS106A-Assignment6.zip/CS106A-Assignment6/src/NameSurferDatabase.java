// TODO: comment this file

import java.io.*;
import java.util.*;

public class NameSurferDatabase implements NameSurferConstants {
	
	// TODO: comment this constructor
	public NameSurferDatabase(String filename) {
		// TODO: fill this in
	}
	
	// TODO: comment this method
	public NameSurferEntry findEntry(String name) {
		// TODO: implement this method

		return null;	// remove this line
	}
}

