/*
 * File: BiasBarsGraph.java
 * ---------------------------
 * This class represents the canvas on which the graph of
 * frequencies is drawn. This class is responsible for updating
 * (redrawing) the graphs whenever the current entry changes
 * or the window is resized.
 */

import acm.graphics.*;
import java.awt.event.*;
import java.util.*;
import java.awt.Color;

public class BiasBarsGraph extends GCanvas implements ComponentListener {
	
	/** An array of the comment sources for the data. The order of the data in gender-data.txt will line up with this array. */	
	private static final String[] COMMENT_SOURCES = {"Facebook (pol.)", "Facebook (celeb.)", "TEDTalks", "Reddit", "Fitocracy"};

	/** The number of frequencies to label, from 0 to the maximum frequency shown */
	private static final int NLABELS = 11;

	/** The number to round the up to when choosing the maximum value shown on the y-axis */
	private static final int MAGNITUDE = 10;
	
	/** The total width of the bars for each comment source (the width of an actual bar will be half of this) */
	private static final int BARS_WIDTH = 150;

	/** The number of pixels to reserve at the top and bottom of the canvas */
	private static final int VERTICAL_MARGIN = 30;
	
	/** The number of pixels between the left side of the canvas and the left y-axis */
	private static final int LEFT_MARGIN = 50;
	
	/** The number of pixels between the right side of the canvas and the right y-axis */
	private static final int RIGHT_MARGIN = 30;
	
	/** The total length of each tick mark drawn on the y-axis */
	private static final int TICK_MARK_LENGTH = 8;
	
	/** The number of pixels between each axis and its labels */
	private static final int LABEL_OFFSET = 5;

	/** The maximum frequency on the y-axis when there is no current entry */
	private static final int DEFAULT_MAX_FREQ = 1000;

	// TODO add instance variable(s)
	
	/**
	* Creates a new NameSurferGraph object that displays the data.
	*/
	public BiasBarsGraph() {
		addComponentListener(this);
		// TODO implement the rest of this constructor
	}
	
	
	/**
	* Clears the current entry stored inside this class. This method should 
	* not affect the appearance of the graph; that is done by calling update.
	*/
	public void clear() {
		// TODO implement this method
	}
	
	
	/**
	* Specifies a BiasBarsEntry to be the entry shown on the display.
	* Note that this method does not actually draw the graph, but
	* simply stores the entry; the graph is drawn by calling update.
	*/
	public void addEntry(BiasBarsEntry entry) {
		// TODO implement this method
	}
	
	
	/**
	* Updates the display image by deleting all the graphical objects
	* from the canvas and then reassembling the display according to
	* the current entry. Your application must call update after
	* calling either clear or addEntry; update is also called whenever
	* the size of the canvas changes.
	*/
	public void update() {
		// TODO implement this method
	}
	
	/* Implementation of the ComponentListener interface */
	public void componentHidden(ComponentEvent e) { }
	public void componentMoved(ComponentEvent e) { }
	public void componentResized(ComponentEvent e) { update(); }
	public void componentShown(ComponentEvent e) { }
}
