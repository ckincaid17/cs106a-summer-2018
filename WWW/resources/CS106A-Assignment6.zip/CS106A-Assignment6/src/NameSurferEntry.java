// TODO: comment this file

import java.util.*;

public class NameSurferEntry implements NameSurferConstants {

	// TODO: comment this constructor
	public NameSurferEntry(String dataLine) {
		// TODO: implement this constructor
	}

	// TODO: comment this method
	public String getName() {
		// TODO: implement this method

		return "";	// remove this line
	}

	// TODO: comment this method
	public int getRank(int decadesSince1900) {
		// TODO: implement this method

		return 0;	// remove this line
	}

	// TODO: comment this method
	public String toString() {
		// TODO: implement this method

		return "??????";	// remove this line
	}
}

