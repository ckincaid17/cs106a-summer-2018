/*
 * File: BiasBars.java
 * ---------------------
 * When it is finished, this program will implement the viewer for
 * the descriptor frequency data described in the assignment handout.
 */

import acm.program.*;
import java.awt.event.*;
import javax.swing.*;

public class BiasBars extends Program {

	/** The name of the file containing the data */
	private static final String DATA_FILE = "res/gender-data.txt";
	
	/** The width of the text field in the NORTH of the window */
	private static final int TEXT_FIELD_WIDTH = 16;
	
	// TODO add instance variable(s)
	
	/**
	 * This method has the responsibility for creating the database
	 * and initializing the interactors at the top of the window.
	 */
	public void init() {
		setTitle("BiasBars");
		// TODO implement this method, along with any helper methods you want
	}

	/**
	 * This class is responsible for detecting when the buttons are
	 * clicked, so you will have to define a method to respond to
	 * button actions.
	 */
	public void actionPerformed(ActionEvent e) {
		// TODO implement this method
	}
}
