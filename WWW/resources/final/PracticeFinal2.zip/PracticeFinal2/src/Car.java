/* FILE: Car.java
 * ---------------
 * This class models a car and keeps track of the car's mileage, gas left,
 * and breakdown status. You can take the car out for drives, each drive
 * consumes gas and has a % chance of causing a breakdown.
 * The breakdown chance is 0.1 if you've driven 0-10000 miles, 
 * 0.2 for 10,001 - 20000 miles, etc.
 * If the car breaks down or doesn't have enough gas for the trip,
 * you cannot drive it.
 */

import acm.util.*;

public class Car {
	
	private static final int MILES_PER_GALLON = 25;
	
	// The number of miles the car has been driven
	private int mileage;
	
	// The amount of gas left in the tank
	private double gasLeft;
	
	// Whether the car is broken down
	private boolean isBroken;
	
	// This constructor initializes a car with some gas and mileage.
	public Car(int initialGasVolume, int existingMileage) {
		gasLeft = initialGasVolume;
		mileage = existingMileage;
		isBroken = false;
	}
	
	/*
	 * This method attempts to turn on the car and drive it the given distance.
	 * There is a chance when it turns on that it breaks down - if it does, it
	 * cannot drive, and returns false.
	 * 
	 * Otherwise, it drives the given distance, updating its mileage and gas left.
	 * If it does not have enough gas, it drives until its tank is empty, and returns
	 * false.  If it has enough gas, it drives the full distance and returns true.
	 */
	public boolean turnOnAndDrive(int milestToDrive) {
		double breakdownChance = (mileage / 10000) * 0.1;
		
		if (RandomGenerator.getInstance().nextBoolean(breakdownChance)) {
			// If we break down...
			isBroken = true;
			return false;
		} else if (gasLeft * MILES_PER_GALLON >= milestToDrive) {
			// If we have enough gas for the full trip...
			mileage += milestToDrive;
			gasLeft -= ((double)milestToDrive / MILES_PER_GALLON);
			return true;
		} else {
			// We don't have enough gas
			mileage += gasLeft * MILES_PER_GALLON;
			gasLeft = 0;
			return false;
		}
	}
	
	// This method returns the number of miles this car has driven.
	public int getMileage() {
		return mileage;
	}
	
	// This method returns whether the car is broken down or not.
	public boolean isBrokenDown() {
		return isBroken;
	}
	
	// This method sets the car as no longer broken down.
	public void repair() {
		isBroken = false;
	}
	
	// This method adds the given number of gallons of gas to the tank.
	public void fillGas(int numberOfGallons) {
		gasLeft += numberOfGallons;
	}
}