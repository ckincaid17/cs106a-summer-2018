/* FILE: Nim.java
 * --------------
 * This program plays a graphical version of the game of Nim.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Nim extends GraphicsProgram {
	private static final int N_COINS = 11;          	/* Number of coins     */
	private static final int COIN_SIZE = 25; 	        /* Diameter of a coin  */
	private static final int COIN_SEP = 10;             /* Space between coins */
	
	private ArrayList<GOval> coinList;
	private boolean isPlayer1sTurn;
	
	public void run() {
		isPlayer1sTurn = true;
		setSize(420, 75); // not required in solution - resizes the window
		setupCoins();
	}
	
	// This method draws N_COINS horizontally and vertically centered.
	private void setupCoins() {
		double widthNeeded = N_COINS * COIN_SIZE + (N_COINS - 1) * COIN_SEP;
		double x = (getWidth() - widthNeeded) / 2.0;
		double y = (getHeight() - COIN_SIZE) / 2.0;
		
		coinList = new ArrayList<>();
		for (int i = 0; i < N_COINS; i++) {
			GOval coin = new GOval(x, y, COIN_SIZE, COIN_SIZE);
			coin.setFilled(true);
			coin.setFillColor(Color.GRAY);
			add(coin);
			coinList.add(coin);
			x += COIN_SIZE + COIN_SEP;
		}
	}
	
	public void mouseClicked(MouseEvent event) {
		GObject obj = getElementAt(event.getX(), event.getY());
		if (obj != null) {
			int index = coinList.indexOf(obj);
			if (index >= coinList.size() - 3) {
				
				// Flip our turn boolean
				isPlayer1sTurn = !isPlayer1sTurn;
				
				// Remove coins from back to front
				for (int i = coinList.size() - 1; i >= index; i--) {
					remove(coinList.get(i));
					coinList.remove(i);
				}
				
				if (coinList.size() == 0) {
					if (isPlayer1sTurn) {
						add(new GLabel("Player 1 wins!"), 50, 50);
					} else {
						add(new GLabel("Player 2 wins!"), 50, 50);
					}
				}
			}
		}
	}
}