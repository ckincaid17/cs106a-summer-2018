/* FILE: Teacher.java
 * --------------
 * This program prints out the letter grades received by different students.
 * 
 * NOTE: this program uses LinkedHashMap in place of HashMap in some places, in
 * order to guarantee a certain ordering, as mentioned in one of the problem
 * assumptions.  This is used just for this assumption, and you do not need to
 * be familiar with LinkedHashMap.
 */
import acm.program.*;
import java.util.*;

public class Teacher extends ConsoleProgram {
	public void run() {
		HashMap<String, Integer> roster = new HashMap<>();
		roster.put("Mort", 77);
		roster.put("Dan", 81);
		roster.put("Alyssa", 98);
		roster.put("Kim", 52);
		roster.put("Lisa", 87);
		roster.put("Bob", 43);
		roster.put("Jeff", 70);
		roster.put("Sylvia", 92);
		roster.put("Vikram", 90);

		HashMap<Integer, String> gradeMap = new LinkedHashMap<>();
		gradeMap.put(52, "D");
		gradeMap.put(70, "C-");
		gradeMap.put(73, "C");
		gradeMap.put(76, "C+");
		gradeMap.put(80, "B-");
		gradeMap.put(84, "B");
		gradeMap.put(87, "B+");
		gradeMap.put(89, "A-");
		gradeMap.put(91, "A");
		gradeMap.put(98, "A+");

		println(teacher(roster, gradeMap));
		println(teacher(roster, new HashMap<Integer, String>()));
		println(teacher(new HashMap<String, Integer>(), gradeMap));
	}
	
	
	private HashMap<String, String> teacher(HashMap<String, Integer> students, HashMap<Integer, String> gradeMap) {
		return teacher1(students, gradeMap);
	}

	// solution 1
	private HashMap<String, String> teacher1(HashMap<String, Integer> students, HashMap<Integer, String> gradeMap) { 
		HashMap<String, String> result = new HashMap<>();
		for (String student : students.keySet()) {
			int studentPercent = students.get(student);
			// figure out this student's grade from the mapping 
			String grade = "F";
			for (int percent : gradeMap.keySet()) {
				if (studentPercent >= percent) {
					grade = gradeMap.get(percent);
				} 
			}
			if (gradeMap.size() > 0) {
				result.put(student, grade);
			}
		}
		return result;
	}

	// solution 2: count down
	private HashMap<String, String> teacher2(HashMap<String, Integer> students, HashMap<Integer, String> gradeMap) { 
		// find minimum value in grade map
		int min = Integer.MAX_VALUE;
		for (int pct : gradeMap.keySet()) { 
			min = Math.min(min, pct); 
		}
		HashMap<String, String> result = new HashMap<>();
		if (gradeMap.size() > 0) {
			for (String student : students.keySet()) {
				int pct = students.get(student);
				if (pct < min) {
					result.put(student, "F");
				} else {
					// count down by 1% at a time until we find a percentage in the grade mapping 
					while (!gradeMap.containsKey(pct)) {
						pct--; 
					}
					result.put(student, gradeMap.get(pct));
				}
			}
		}
		return result;
	}

	// solution 3: gradeMap as outer loop
	private HashMap<String, String> teacher3(HashMap<String, Integer> students, HashMap<Integer, String> gradeMap) { 
		HashMap<String, String> result = new HashMap<>();
		for (int pct : gradeMap.keySet()) {
			String grade = gradeMap.get(pct);
			for (String student : students.keySet()) {
				int studentPct = students.get(student);
				if (studentPct >= pct) {
					result.put(student, grade);
				} else if (!result.containsKey(student)) {
					result.put(student, "F");
				} 
			}
		}
		return result;
	}
}
