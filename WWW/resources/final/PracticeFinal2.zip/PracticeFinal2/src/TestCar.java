/* FILE: TestCar.java
 * ------------------
 * This program tests the functionality of the testCar method,
 * which returns how many miles a new car goes before it breaks down.
 */
import acm.program.*;

public class TestCar extends ConsoleProgram {
	public void run() {
		println(testCar());
	}
	
	// Tests to see how far a new car can go before it breaks down.
	private double testCar() {
		Car c = new Car(10, 0);
		while (!c.isBrokenDown()) {
			if (!c.turnOnAndDrive(10)) {
				c.fillGas(10);
			}
		}
		
		return c.getMileage();
	}
}
