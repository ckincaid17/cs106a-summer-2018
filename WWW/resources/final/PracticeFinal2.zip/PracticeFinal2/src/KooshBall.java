/* FILE: KooshBall.java
 * ---------------
 * This class allows the user to add lines of different colors to
 * the graphics canvas. Every line has a randomly chosen start
 * point, while the end point is always in the center.
 * The user can choose to remove the very last line entered, but
 * if they click the button again it should not remove any more lines
 * until the user has added another line to the canvas.
 */

import java.awt.Color;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import acm.graphics.*;
import acm.program.*;
import acm.util.*;

public class KooshBall extends GraphicsProgram {
	// This constant is provided to you
	private static final HashMap<String, Color> colorMap = makeMap();
	
	private static final int TEXT_FIELD_WIDTH = 16;
	
	// The most recent line added
	private GLine lastLine;
	private JTextField colorField;
	
	// Code that initializes map - you did NOT have to write this
	private static HashMap<String, Color> makeMap() {
		HashMap<String, Color> map = new HashMap<String, Color>();
		map.put("red", Color.RED);
		map.put("blue", Color.BLUE);
		map.put("green", Color.GREEN);
		map.put("black", Color.BLACK);
		return map;
	}
	
	public void init() {
		add(new JLabel("Color: "), SOUTH);
		colorField = new JTextField(TEXT_FIELD_WIDTH);
		add(colorField, SOUTH);
		colorField.setActionCommand("Add");
		colorField.addActionListener(this);
		
		add(new JButton("Add"), SOUTH);
		add(new JButton("Remove Last"), SOUTH);
		addActionListeners();
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Add")) {
			Color c = colorMap.get(colorField.getText().toLowerCase());
			
			// If the color is in the map, add a new line
			if (c != null) {
				RandomGenerator rgen = RandomGenerator.getInstance();
				int randomX = rgen.nextInt(getWidth());
				int randomY = rgen.nextInt(getHeight());
				lastLine = new GLine(randomX, randomY, getWidth() / 2, getHeight() / 2);
				lastLine.setColor(c);
				add(lastLine);
			}
		} else {
			if (lastLine != null) {
				remove(lastLine);
				lastLine = null;
			}
		}
	}
}