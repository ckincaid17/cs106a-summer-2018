import java.util.*;
import acm.program.*;

/* Note that, because HashMaps are unordered in real life,
 * the output of this program may not exactly match the exam answers,
 * which is ok.
 * 
 * Exam answers:
 * a) [ok, dog, horse, horse]
 * b) [fruit, hyena, bird, hello, hello]
 * c) [hhh, gg, e]
 * d) [doggie robot]
 */
public class Mystery2 extends ConsoleProgram {
	public void run() {
		String[] mapStrings = {
				"horse cow cow horse dog cat ok yo",
				"bye hello bird dog hi hello hyena apple fruit meat",
				"a b c d e a ff a gg c hhh ff",
				"karel robot robot karel daisy dog doggie daisy"
		};
		
		for (String mapString : mapStrings) {
			HashMap<String, String> map = createMap(mapString);
			collectionMystery2(map);
		}
	}
	
	private void collectionMystery2(HashMap<String, String> map) {
	    ArrayList<String> list = new ArrayList<>();
	    for (String key : map.keySet()) {
	        if (map.get(key).length() > key.length()) {
	            list.add(map.get(key));
	        } else {
	            list.add(0, key);
	            list.remove(map.get(key));
	        } 
	    }
	    println(list);
	}
	
	/*
	 * This method is a utility method that takes a string of the format 
	 * "KEY VALUE KEY VALUE" and returns a map with those key/value pairs.
	 */
	private HashMap<String, String> createMap(String mapString) {
		HashMap<String, String> map = new HashMap<>();
		
		Scanner s = new Scanner(mapString);
		while (s.hasNext()) {
			String key = s.next();
			String value = s.next();
			map.put(key, value);
		}
		s.close();
		
		return map;
	}
}
