/* FILE: Tile.java
 * ---------------
 * This program tests the tile method, which tiles an
 * image to fill a given width and height.
 */
import acm.graphics.*;
import acm.program.*;

public class Tile extends GraphicsProgram {
	public void run() {
		GImage image = new GImage("res/smiley-face.png");
		tile(image, 700, 630);
		add(image);
	}
	
	private void tile(GImage source, int width, int height) {
		tile1(source, width, height);
	}

	// solution 1: result image pixel based
	private void tile1(GImage source, int width, int height) {
		int[][] pixels = source.getPixelArray();
		int[][] result = new int[height][width];
		for (int row = 0; row < height; row++) {
			for (int col = 0; col < width; col++) {
				result[row][col] = pixels[row % pixels.length][col % pixels[0].length];
			}
		}
		source.setPixelArray(result);
	}

	// solution 2: source image pixel based
	private void tile2(GImage source, int width, int height) {
		int[][] pixels = source.getPixelArray();
		int[][] result = new int[height][width];
		for (int row = 0; row < pixels.length; row++) {
			for (int col = 0; col < pixels[0].length; col++) {
				
				// tile the individual pixel of pixels[row][col] 
				for (int y = row; y < height; y += pixels.length) {
					for (int x = col; x < width; x += pixels[0].length) { 
						result[y][x] = pixels[row][col];
					}
				} 
			}
		}
		source.setPixelArray(result);
	}
}