/* FILE: Sequences.java
 * ---------------------
 * This program tests the contains method,
 * which returns true if one array's sequence
 * of elements appears in another.
 */
import acm.program.*;

public class Sequences extends ConsoleProgram {
	public void run() {
		int[] a1 = {1, 6, 2, 1, 4, 1, 2, 1, 8};
		int[] a2 = {1, 2, 1};
		println("contains(a1, a2) = " + contains(a1, a2));

		a2[0] = 2;
		a2[1] = 1;
		a2[2] = 2;
		println("contains(a1, a2) = " + contains(a1, a2));

		println("contains(a1, a1) = " + contains(a1, a1));
	}

	private boolean contains(int[] a1, int[] a2) {
		return contains1(a1, a2);
	}

	// solution 1: nested loops
	private boolean contains1(int[] a1, int[] a2) {
		for (int i = 0; i <= a1.length - a2.length; i++) {
			boolean found = true;
			for (int j = 0; j < a2.length; j++) {
				if (a1[i + j] != a2[j]) {
					found = false;
				}
			}
			if (found) {
				return true;
			}
		}
		return false; 
	}

	// solution 2: a variation of first solution that uses a count instead of a boolean
	private boolean contains2(int[] a1, int[] a2) {
		for (int i = 0; i <= a1.length - a2.length; i++) {
			int count = 0;
			for (int j = 0; j < a2.length; j++) {
				if (a1[i + j] == a2[j]) {
					count++;
				}
			}
			if (count == a2.length) {
				return true;
			}
		}
		return false; 
	}

	// solution 3: a single while loop
	private boolean contains3(int[] a1, int[] a2) { 
		int i1 = 0;
		int i2 = 0;
		while (i1 < a1.length && i2 < a2.length) {
			if (a1[i1] != a2[i2]) { // doesn't match; start over
				i2 = 0; 
			}
			if (a1[i1] == a2[i2]) { // important NOT to use else-if here
				i2++; 
			}
			i1++; 
		}
		return i2 >= a2.length;
	}

	// solution 4: for loop with inner while loop
	private boolean contains4(int[] a1, int[] a2) { 
		for (int i = 0; i < a1.length; i++) {
			int j = 0;
			while (j < a2.length && i + j < a1.length && a1[i + j] == a2[j]) {
				j++;
			}
			if (j == a2.length) {
				return true;
			}
		}
		return false; 
	}
}
