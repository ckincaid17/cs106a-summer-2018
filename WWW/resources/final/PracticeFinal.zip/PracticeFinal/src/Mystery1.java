import acm.program.*;
import java.util.*;

public class Mystery1 extends ConsoleProgram {
	public void run() {
        int y = 1;
        int x = 3;
        int[] a = new int[4];

        mystery(a, y, x);
        println(x + " " + y + " " + Arrays.toString(a));

        x = y - 1;
        mystery(a, y, x);
        println(x + " " + y + " " + Arrays.toString(a));
	}
	private void mystery(int[] a, int x, int y) {
		if (x < y) {
			x++;
        	a[x] = 17;
        } else {
			a[y] = 17;
		}
        println(x + " " + y + " " + Arrays.toString(a));
    }
}