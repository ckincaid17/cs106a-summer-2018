import acm.program.*;
import acm.util.*;

public class NeverendingBirthdayParty extends ConsoleProgram {
    public void run() {
        RandomGenerator rgen = RandomGenerator.getInstance();
        boolean[] used = new boolean[366];
        int numLeft = 366;
        int numPeople = 0;

        while (numLeft > 0) {
            int birthday = rgen.nextInt(0, 365);
            if (!used[birthday]) {
                 numLeft--;
                 used[birthday] = true;
            }
            ++numPeople;
        }
        println("We needed " + numPeople + " in our group.");
    }
}
