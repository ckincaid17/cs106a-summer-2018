import acm.program.*;
import acm.graphics.*;
import javax.swing.*;
import java.awt.event.*;

public class SignMaker extends GraphicsProgram {
	private int labelY;
	private JTextField line;
	private JTextField font;

	public void init() {
		line = new JTextField(30); 
		line.addActionListener(this);
		font = new JTextField(15); 
		font.setText("Times-Bold-36"); 
		labelY = 0;
		add(new JLabel("Line: "), SOUTH); 
		add(line, SOUTH);
		add(new JLabel(" Font: "), SOUTH); 
		add(font, SOUTH);
	}
	
	public void actionPerformed(ActionEvent e) { 
		if (e.getSource() == line) {
			GLabel label = new GLabel(line.getText()); 
			label.setFont(font.getText());
			labelY += label.getHeight();
			double x = (getWidth() - label.getWidth()) / 2; 
			add(label, x, labelY);
			line.setText("");
		}
	}
}
