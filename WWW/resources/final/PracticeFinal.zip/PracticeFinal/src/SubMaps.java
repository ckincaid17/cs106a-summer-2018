import acm.program.*;
import java.util.*;

public class SubMaps extends ConsoleProgram {
	public void run() {
		HashMap<String, String> map1 = createMap("Smith 949–0504 Marty 206–9024");
		HashMap<String, String> map2 = createMap("Marty 206–9024 Hawking 123–4567 Smith 949–0504 Newton 123–4567");
		println(isSubMap(map1, map2));
	}

	public boolean isSubMap(HashMap<String, String> map1, HashMap<String, String> map2) {
		for (String key : map1.keySet()) {
			if (!map2.containsKey(key) || !map1.get(key).equals(map2.get(key))) {
				return false;
			}
		}
		return true;
	}
	
	/*
	 * This method is a utility method that takes a string of the format 
	 * "KEY VALUE KEY VALUE" and returns a map with those key/value pairs.
	 */
	private HashMap<String, String> createMap(String mapString) {
		HashMap<String, String> map = new HashMap<>();
		
		Scanner s = new Scanner(mapString);
		while (s.hasNext()) {
			String key = s.next();
			String value = s.next();
			map.put(key, value);
		}
		s.close();
		
		return map;
	}
}
