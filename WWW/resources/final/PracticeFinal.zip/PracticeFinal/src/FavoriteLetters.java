import acm.util.*;
import acm.program.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class FavoriteLetters extends Program {
	private JTextField letterField;
	private JLabel output;
	private ArrayList<String> letters;
	
	public void init() {
		setSize(450, 85);	// to make the screen smaller
		letters = new ArrayList<>();
		
		output = new JLabel("[]");
		add(output, NORTH);
		
		letterField = new JTextField(10);
		letterField.setActionCommand("Add");
		letterField.addActionListener(this);
		add(letterField, SOUTH);

		add(new JButton("Add"), SOUTH);
		add(new JButton("Remove"), SOUTH);
		
		addActionListeners();
	}

	public void actionPerformed(ActionEvent event) {
		String cmd = event.getActionCommand();
		String letter = letterField.getText().toLowerCase();
		if (letter.length() == 1) {
			if (cmd.equals("Add")) {
				
				// Add at the front if a duplicate, otherwise the back
				if (letters.contains(letter)) {
					letters.add(0, letter);
				} else {
					letters.add(letter);
				}
			} else if (cmd.equals("Remove")) {
				while (letters.contains(letter)) {
					letters.remove(letter);
				}
			}
		}
		
		// update display
		letterField.setText("");
		output.setText(letters.toString());
	}
}
