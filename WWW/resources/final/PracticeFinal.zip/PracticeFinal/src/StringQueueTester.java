import acm.program.*;

// A test program for the StringQueue class
public class StringQueueTester extends ConsoleProgram {
	public void run() {
		StringQueue queue = new StringQueue ();
		queue.add("Christmas Past");
		queue.add("Christmas Present");
		queue.add("Christmas Future");
		queue.addRandom("Christmas Super Future");
		println(queue.size());
		println(queue.poll());
		println(queue.poll());
		println(queue.poll());
		println(queue.poll());
	}
}
