import java.util.*;
import acm.util.*;

public class StringQueue {

/** Private instance variables */
	private ArrayList<String> waitingLine;

/** Creates a new empty queue. */
	public StringQueue() {
		waitingLine = new ArrayList<String>();
	}
	
/** Adds a new String to the end of the queue */
	public void add(String str) {
		waitingLine.add(str);
	}

/** Adds a new String to a random index in the queue */
   public void addRandom(String str) {
	   RandomGenerator rgen = RandomGenerator.getInstance();
	   int randIndex = rgen.nextInt(waitingLine.size());
		waitingLine.add(randIndex, str);
   }
	
/** Removes and returns the first String (or null if queue is empty) */
	public String poll() {
		if (waitingLine.isEmpty()) return null;
		String first = waitingLine.get(0);
		waitingLine.remove(0);
		return first;
	}

/** Returns the number of entries in the queue. */
	public int size() {
		return waitingLine.size();
	}
}
