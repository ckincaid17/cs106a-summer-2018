import acm.program.*;

public class MagicSquares extends ConsoleProgram {
	
	public void run() {
		int[][] square = {
				{ 4, 9, 2 },
				{3, 5, 7},
				{8, 1, 6}
		};
		println(isMagicSquare(square, 3));
	}
	
	/** Method: isMagicSquare
	 * This method checks an n x n grid to see if it's a magic square.
	 */
	private boolean isMagicSquare(int[][] matrix, int n) {
     /* A 0 x 0 square is valid, in a weird way. */
		if (n == 0) return true;
 
     /* If we don't see all numbers in the range 1 to n2, we can report
      * failure.                                                        */
		if (!allExpectedNumbersFound(matrix, n)) return false;

     /* Sum up the first row to get its value. */
		int expected = rowSum(matrix, 0, n);

     /* Check that all rows and columns have this value. */
		for (int i = 0; i < n; i++) {
			if (rowSum(matrix, i, n) != expected ||
			    colSum(matrix, i, n) != expected)
				return false;
		}
		return true;
	}
	
	/** Method: rowSum
	 * Returns the sum of the given row of the grid.
	 */
	private int rowSum(int[][] grid, int row, int n) {
		int sum = 0;
		for (int i = 0; i < n; i++) {
			sum += grid[row][i];
		}
		return sum;
	}

	/** Method: colSum
	 * Returns the sum of the given column of the grid.
	 */
	private int colSum(int[][] grid, int col, int n) {
		int sum = 0;
		for (int i = 0; i < n; i++) {
			sum += grid[i][col];
		}
		return sum;
	}


	/** Method: allExpectedNumbersFound
	 * This method returns whether all the numbers 1 … n2 are present in the
	 * given grid.
	 */
	private boolean allExpectedNumbersFound(int[][] square, int n) {
	/* Make an array of n2 + 1 booleans to track what numbers are found.  The
	 * +1 is because the numbers range from 1 to n2 and we have to ensure that
	 * there's sufficient space.
	 */
		boolean[] used = new boolean[n * n + 1];

		/* Iterate across the grid and ensure that we've seen everything. */
		for (int row = 0; row < n; row++) {
			for (int col = 0; col < n; col++) {
				/* Make sure the number is in range. */
				if (square[row][col] < 1 || square[row][col] > n * n)
					return false;

				/* Make sure it isn't used. */
				if (used[square[row][col]])
					return false;

				/* Mark the square used. */
				used[square[row][col]] = true;
			}
		}
		/* At this point, we know that all numbers are in range and there are
		 * no duplicates, so everything is valid.
		 */
		return true;
	}
}