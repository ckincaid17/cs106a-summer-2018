import java.util.*;
import acm.program.*;

/* Note that, because HashMaps are unordered in real life,
 * the output of this program may not exactly match the exam answers,
 * which is ok.
 */
public class Mystery2 extends ConsoleProgram {
	public void run() {
		String[] mapStrings = {
				"two deux five cinq one un three trois four quatre",
				"skate board drive car program computer play computer",
				"siskel ebert girl boy heads tails ready begin first last begin end",
				"cotton shirt tree violin seed tree light tree rain cotton"
		};
		
		for (String mapString : mapStrings) {
			HashMap<String, String> map = createMap(mapString);
			collectionMystery2(map);
		}
	}
	
	private void collectionMystery2(HashMap<String, String> map) {
		HashMap<String, String> result = new HashMap<>();
		for (String k : map.keySet()) {
	        String v = map.get(k);
	        if (k.charAt(0) <= v.charAt(0)) {
	            result.put(k, v);
	        } else {
	            result.put(v, k);
	        }
		}
	    println(result);
	}
	
	/*
	 * This method is a utility method that takes a string of the format 
	 * "KEY VALUE KEY VALUE" and returns a map with those key/value pairs.
	 */
	private HashMap<String, String> createMap(String mapString) {
		HashMap<String, String> map = new HashMap<>();
		
		Scanner s = new Scanner(mapString);
		while (s.hasNext()) {
			String key = s.next();
			String value = s.next();
			map.put(key, value);
		}
		s.close();
		
		return map;
	}
}
