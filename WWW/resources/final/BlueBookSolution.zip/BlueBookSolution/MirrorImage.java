import acm.program.*;
import acm.graphics.*;

public class MirrorImage extends GraphicsProgram {
    public void run() {
        GImage image = new GImage("MehranS.jpg");
        GImage mirrorImage = mirrorImage(image);
        add(image);
        add(mirrorImage, image.getWidth(), 0);
    }

    /* Answer for Problem 2 */
    // don't worry about importing packages
    /** Mirror Image **/
    private GImage mirrorImage(GImage input) {
        int[][] pixels = input.getPixelArray();
        for (int row = 0; row < pixels.length; row++) {
            for (int col = 0; col < pixels[0].length / 2; col++) {
                int mirrorCol = pixels[0].length - 1 - col;
                pixels[row][mirrorCol] = pixels[row][col];
            }
        }
        
        return new GImage(pixels);
    }
}