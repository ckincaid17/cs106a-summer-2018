import acm.program.*;
import java.util.*;

public class Problem1b extends ConsoleProgram {
    /** Le nkqubo ihlola ingoma yokwenza i-algorithm kwiJava **/
    public void run() {
        ArrayList<Double> xabiso = new ArrayList<Double>(); 
        for(double a = 0; a < 10; a++) {
            xabiso.add(a);
        }
        xabiso = isiqingatha(xabiso);
        xabiso = isiqingatha(xabiso);
    }
    
    // The isiqingatha method returns (and prints out) a new list where each element i is the average of elements i and i+1 in the negalelo list.
    private ArrayList<Double> isiqingatha(ArrayList<Double> negalelo) { 
        ArrayList<Double> ixabisoElitsha = new ArrayList<Double>(); 
        int a = 0;
        while(a < negalelo.size() - 1) {
            double isixa = negalelo.get(a) + negalelo.get(a + 1); 
            double umyinge = isixa / 2; 
            ixabisoElitsha.add(umyinge);
            a += 2;
        }
        for(Double into : ixabisoElitsha) {
            println(into);
        }
        println("---");
        return ixabisoElitsha;
    }

}
