import acm.program.*;

public class Problem1d extends ConsoleProgram {
    public void run() {
        println("isDivisibleBy(10, 2): " + isDivisibleBy(10, 2));
        println("isDivisibleBy(0, 1): " + isDivisibleBy(0, 1));
        println("isDivisibleBy(11, 3): " + isDivisibleBy(11, 3));
        println("isDivisibleBy(-1, 2): " + isDivisibleBy(-1, 2));
        println("isDivisibleBy(5, -2): " + isDivisibleBy(5, -2));
        println("isDivisibleBy(20, 40): " + isDivisibleBy(20, 40));
        println("isDivisibleBy(40, 20): " + isDivisibleBy(40, 20));
    }

    /* Answer for 1D */
    // don't worry about importing packages
    // if a is less than b you should return false
    // if either a or b is 0 or negative you should return false
    // otherwise return true only if a divides by b perfectly
    // with no remainder.
    private boolean isDivisibleBy(int a, int b) {
        if (a < b || a <= 0 || b <= 0) return false;
        return a % b == 0;
    }
}
