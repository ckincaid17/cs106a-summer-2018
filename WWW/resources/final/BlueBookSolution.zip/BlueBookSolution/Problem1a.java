import acm.program.*;

public class Problem1a extends ConsoleProgram {
    public void run() {
        powersOfTwo(128);
    }

    /* Answer for 1A */
    // don't worry about importing packages
    // print out all powers of two between 1 and max, inclusive
    // max will be a >= 1
    private void powersOfTwo(int max) {
        int num = 1;
        while (num <= max) {
            println(num);
            num *= 2;
        }
    }
}
