/*
 * File: BakerRank.java
 * ---------------------
 * Interactors, events, animation, 1D arrays
 */

import java.awt.Color;
import java.awt.event.*;

import javax.swing.*;

import acm.graphics.*;
import acm.program.GraphicsProgram;

public class BakerRank extends GraphicsProgram {

	private static final String[] BAKERS = {"Ruby", "Ali", "Rob", "Kimberley", "Howard"};
	private static final int DELAY = 1000;

	private String[] bakerRanks;
	private boolean[] alreadyRanked;
	private int currRank;

	public void init() {
		int numBakers = BAKERS.length;
		currRank = numBakers - 1;
		bakerRanks = new String[numBakers];
		alreadyRanked = new boolean[numBakers];
		for (int i = 1; i <= numBakers; i++) {
			add(new JButton("Pie " + i), NORTH);
		}
		addActionListeners();
	}

	public void run() {
		int numBakers = BAKERS.length;
		int imageIndex = 0;
		// Placeholder so that we can use setImage
		GImage background = new GImage(BAKERS[0] + ".jpg");
		add(background);
		while (currRank >= 0) {
			background.setImage(BAKERS[imageIndex] + ".jpg");
			background.setSize(getWidth(), getHeight());
			imageIndex = (imageIndex + 1) % numBakers;
			pause(DELAY);
		}
		for (int i = 0; i < BAKERS.length; i++) {
			add(new JLabel(i + 1 + ": " + bakerRanks[i]), SOUTH);
		}
	}
		
	@Override
	public void actionPerformed(ActionEvent e) {
		String buttonText = e.getActionCommand();
		// Move past "Pie "
		String pieNumberString = buttonText.substring(4);
		int bakerSelected = Integer.parseInt(pieNumberString) - 1;
		if (!alreadyRanked[bakerSelected]) {
			bakerRanks[currRank--] = BAKERS[bakerSelected];
			alreadyRanked[bakerSelected] = true;
		}
	}
}
