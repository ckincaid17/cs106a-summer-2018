/*
 * File: FurnitureCatalog.java
 * ---------------------
 * Classes, HashMaps, ArrayLists, file reading
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

import acm.program.*;

public class FurnitureCatalog {

	private HashMap<String, ArrayList<Double>> catalog;

	/* Creates a new furniture catalog
	 * given a file of initial items and their prices.
	 */
	public FurnitureCatalog(String filename) {
		catalog = new HashMap<>();
		try {
			Scanner sc = new Scanner(new File(filename));
			while (sc.hasNextLine()) {
				Scanner tokens = new Scanner(sc.nextLine());
				addItem(tokens.next(), tokens.nextDouble());
				tokens.close();
			}
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	/* Returns a list of all the prices in this catalog for the given item.
	 */
	public ArrayList<Double> getPriceOptions(String furnitureItem) {
		return catalog.get(furnitureItem.toLowerCase());
	}

	/* Returns a list of all the items that only appear once in this catalog.
	 */
	public ArrayList<String> getMustBuys() {
		ArrayList<String> mustBuys = new ArrayList<>();
		for (String item : catalog.keySet()) {
			ArrayList<Double> prices = catalog.get(item);
			if (prices.size() == 1) {
				mustBuys.add(item);
			}
		}
		return mustBuys;
	}
	
	/* Adds an item and its price to this catalog. The item may be new,
     * or it may already be in the catalog. Does nothing if the catalog
     * already has an entry with this price for the given item.
     */
	public void addItem(String item, double price) {
		ArrayList<Double> prices = catalog.get(item);
		if (prices == null) {
			prices = new ArrayList<Double>();
		}
		if (!prices.contains(price)) {
			prices.add(price);
			catalog.put(item, prices);
		}
	}
}
