/* File: FourInARowGame.java
 * -------------------
 * 2D arrays, extending GCanvas
 */

import java.awt.Color;
import java.util.*;

import acm.graphics.*;
import acm.program.*;

public class FourInARowGame extends ConsoleProgram {

	private FourInARowBoard board;

	public void init() {
		int nRows;
		int nCols;
		do {
			nRows = readInt("How many rows should the board have? ");
		} while (nRows < 4);
		do {
			nCols = readInt("How many columns should the board have? ");
		} while (nCols < 4);
		board = new FourInARowBoard(nRows, nCols);
		add(board);
	}

	public void run() {
		while (!board.gameOver()) {
			takeTurn(Color.RED);
			if (!board.gameOver()) {
				takeTurn(Color.BLACK);
			}
		}
		println("Game over!");
	}

	// Part C
	private void takeTurn(Color player) {
		while (true) {
			int row = readInt("Row? ");
			int col = readInt("Col? ");

			String validationError = board.validateMove(row, col);
			if (validationError == null) {
				board.playPiece(row, col, player);
				return;
			}
			println(validationError);
		}
	}
}
