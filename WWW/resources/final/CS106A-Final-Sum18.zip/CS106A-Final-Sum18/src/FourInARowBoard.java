/* File: FourInARowBoard.java
 * -------------------
 * 2D arrays, extending GCanvas
 */

import java.awt.Color;
import java.util.*;

import acm.graphics.*;
import acm.program.*;

public class FourInARowBoard extends GCanvas {

	private static final int DIAMETER = 100;
	private static final Color EMPTY = Color.WHITE;

	private GOval[][] pieces;

	/* === Board creation === */

	public FourInARowBoard(int nRows, int nCols) {
		pieces = createPieces(nRows, nCols);
		displayBoard();
	}

	private GOval[][] createPieces(int nRows, int nCols) {
		GOval[][] gamePieces = new GOval[nRows][nCols];
		for (int r = 0; r < nRows; r++) {
			for (int c = 0; c < nCols; c++) {
				gamePieces[r][c] = new GOval(DIAMETER, DIAMETER);
				gamePieces[r][c].setColor(EMPTY);
				gamePieces[r][c].setFilled(true);
			}
		}
		return gamePieces;
	}

	private void displayBoard() {
		int nRows = pieces.length;
		int nCols = pieces[0].length;
		GRect pieceHolder = new GRect(nCols * DIAMETER, nRows * DIAMETER);
		pieceHolder.setColor(Color.YELLOW);
		pieceHolder.setFilled(true);
		add(pieceHolder);
		for (int r = 0; r < nRows; r++) {
			for (int c = 0; c < nCols; c++) {
				add(pieces[r][c], c * DIAMETER, r * DIAMETER);
			}
		}
	}

	/* === Making moves === */

	// Part A
	public String validateMove(int row, int col) {
		if (!moveInBounds(row, col)) {
			return "That space is not on the board!";
		} else if (pieces[row][col].getColor() != EMPTY) {
			return "That space is already taken!";
		} else if (row != pieces.length - 1 && pieces[row + 1][col].getColor() == EMPTY) {
			return "That move is gravitationally impossible!";
		}
		return null;
	}

	private boolean moveInBounds(int row, int col) {
		int nRows = pieces.length;
		int nCols = pieces[0].length;
		return row >= 0 && row < nRows && col >= 0 && col < nCols;
	}

	// Part B
	public void playPiece(int row, int col, Color player) {
		pieces[row][col].setColor(player);
	}

	/* === Ending the game === */

	public boolean gameOver() {
		return isDraw() || diagonalWin();
	}

	private boolean isDraw() {
		for (int r = 0; r < pieces.length; r++) {
			for (int c = 0; c < pieces[0].length; c++) {
				if (pieces[r][c].getColor() == EMPTY) {
					return false;
				}
			}
		}
		return true;
	}

	// Part D
	private boolean diagonalWin() {
		int nRows = pieces.length;
		int nCols = pieces[0].length;

		// Starting row at 3 and ending col at nCols - 4 are optimizations
		for (int row = 3; row < nRows; row++) {
			for (int col = 0; col < nCols - 3; col++) {
				Color streakColor = pieces[row][col].getColor();
				if (streakColor != EMPTY) {
					int streak = 1;
					int nextRow = row - 1;
					int nextCol = col + 1;
					while (inBounds(nextRow, nextCol) &&
							pieces[nextRow][nextCol].getColor() == streakColor) {
						streak++;
						nextRow--;
						nextCol++;
					}
					if (streak >= 4) {
						return true;
					}
				}
			}
		}

		return false;
	}
}
