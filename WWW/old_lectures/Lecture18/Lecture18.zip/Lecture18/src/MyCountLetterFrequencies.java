/* File: MyHistogram.java
 * --------------------
 * A program that reads in temperature data from
 * temps.txt and outputs a histogram of the data using
 * an array as a frequency counter.
 * --------------------
 */

import java.awt.*;
import java.awt.event.*;
import acm.graphics.*;
import acm.program.*;
import acm.util.*;

public class MyHistogram extends GraphicsProgram {
	
}
