/*
 * CS 106A, Week 3, File Processing
 * 
 * This program computes leader in presidential polls, using
 * an input file such as: 
 * AK 42 53 3 Oct Ivan Moore Research
 * AZ 71 26 6 Sep University of Arizona McKale Center
 */

import acm.program.*;
import java.io.*;    // for File
import java.util.*;  // for Scanner

public class MyElection extends ConsoleProgram {
	public void run() {
		
	}
}
