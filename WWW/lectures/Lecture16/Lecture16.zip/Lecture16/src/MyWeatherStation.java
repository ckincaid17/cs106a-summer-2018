/* File: MyWeatherStation
 * --------------------
 * This program shows how we can use arrays to do
 * more complex data manipulation.  It prompts the user
 * for a variable number of daily temperatures, and then prints
 * out all the entered temperatures along with statistics such as
 * the average, number of days above average,
 * and the hottest and coldest days.
 * --------------------
 */

import acm.program.*;
import java.util.*;

public class MyWeatherStation extends ConsoleProgram {
	public void run() {
		// TODO
	}
}
