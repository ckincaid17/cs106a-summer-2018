/* File: Employee.java
 * -------------------
 * This file defines a new variable type called Employee.
 * An Employee has a name, title, and salary.  It has getters
 * for all of them, and has a method to promote the employee,
 * which doubles its salary and adds "Senior" to the title,
 * if its salary is under $1000.
 * 
 * You can create an Employee variable by specifying either the
 * employee name, or the name, title and salary.
 */
public class Employee {
	
}
