/*
 * File: Roomba.java
 * -----------------------
 * Karel starts at (1, 1) facing east and cleans up any
 * beepers scattered throughout his world.
 */

import stanford.karel.*;

public class BlankRoomba extends SuperKarel {

	public void run() {
		// TODO: Write this program for practice!
	}
}
