/* File: MyTicTacToe.java
 * -------------------
 * This program uses 2D arrays to play the game "Tic-Tac-Toe".
 * -------------------
 */

import acm.program.*;

public class MyTicTacToe extends ConsoleProgram {
	public void run() {
		
	}
}
