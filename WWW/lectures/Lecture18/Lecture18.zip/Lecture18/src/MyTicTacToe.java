/* File: MyTicTacToe.java
 * -------------------
 * This program uses 2D arrays to play the game "Tic-Tac-Toe".
 * -------------------
 */

import java.util.Arrays;
import java.util.Scanner;

import acm.program.*;

public class MyTicTacToe extends ConsoleProgram {
	
	private static final char EMPTY = ' ';

	public void run() {
		// TODO fill in code for playing game!
		println("Game over!");
	}
}
