/* File: MyEmployeeProgram.java
 * --------------------------
 * This file is an example program using the new variable
 * type we defined, Employee.
 */
import acm.program.*;

public class MyEmployeeProgram extends ConsoleProgram {
	public void run() {
		// Make bank accounts for Colin and Annie
		// Print Annie's salary
		// Print Colin's account information
		// Promote Colin as much as possible, displaying new job info each time
	}
}
