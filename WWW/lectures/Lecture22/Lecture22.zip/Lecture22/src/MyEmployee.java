/* File: MyEmployee.java
 * -------------------
 * This file defines a new variable type called Employee.
 * An Employee has a name, title, and salary. It has getters
 * for all of them, and has a method to promote the employee,
 * which doubles its salary and adds "Senior" to the title,
 * if its salary is under $1000.
 * 
 * You can create an Employee variable by specifying either the
 * employee name, or the name, title and salary.
 */
public class MyEmployee {
	
	// Step 1: what information is in an Employee?
	
	// Step 2: how do you create an Employee?
	
	// Step 3: what can an employee do?
	
	// How do we want to print out an object of this type?
	// Colin (Karel Programmer) makes $9
}
