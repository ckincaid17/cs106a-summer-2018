/*
 * File: PythagoreanTheorem.java
 * Name: 
 * Section Leader: 
 * -----------------------------
 * This file is the starter file for the PythagoreanTheorem problem.
 */

import acm.graphics.*;
import acm.program.*;

public class StringArt extends GraphicsProgram {
	
	private static final int NUM_STRINGS = 10;
	
	public static final int APPLICATION_WIDTH = 600;
	public static final int APPLICATION_HEIGHT = 600;
	
	public void run() {
		
	}

}
