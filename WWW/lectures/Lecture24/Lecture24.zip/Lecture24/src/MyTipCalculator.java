/* File: MyTipCalculator.java
 * ------------------------
 * This program demonstrates using interactors
 * to let a user calculate a tip for their bill.
 */
import javax.swing.*;
import acm.program.*;
import java.awt.event.*;

public class MyTipCalculator extends ConsoleProgram {

	
}
