/*
 * File: HelloWorld.java
 * ---------------------
 * This program prints out hello world!
 */

import acm.program.*;

public class HelloWorld extends ConsoleProgram {
	public void run() {
		println("Hello, world!");
	}
}

