
import stanford.karel.*;

public class Place99Beepers extends SuperKarel {
	public void run() {
		// todo
	}
}
