
import stanford.karel.*;

public class BeeperLine extends SuperKarel {

	public void run() {
		for(int i = 0; i < 4; i++) {
			putBeeper();
			move();
		}
	}
}
