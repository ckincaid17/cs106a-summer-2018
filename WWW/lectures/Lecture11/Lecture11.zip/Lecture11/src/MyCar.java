/*
 * File: MyCar.java
 * --------------
 * A graphics program that draws a car with a body, 2 wheels,
 * and a windshield, on a yellow background.
 */
import acm.program.*;
import acm.graphics.*;
import java.awt.*;

public class MyCar extends GraphicsProgram {
	public void run() {
		// TODO Draw the car described on the slide!
	}
}
