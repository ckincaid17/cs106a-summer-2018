/*
 * File: MyStoplights.java
 * -----------------
 * A program that uses a decomposed method to draw one
 * or more "stoplight" graphics that each consist of a series of
 * red-yellow-green lights on a gray background.
 */

import acm.program.*;
import acm.graphics.*;
import java.awt.*;

public class MyStoplights extends GraphicsProgram {
	public void run() {
		addStoplight(/* TODO: add necessary parameters */);
	}
	
	private void addStoplight(/* TODO: add necessary parameters */) {
		
	}
}
