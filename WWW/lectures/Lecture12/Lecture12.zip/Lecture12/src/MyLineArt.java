/*
 * File: MyLineArt.java
 * -----------------
 * A program that draws many lines to simulate the
 * illusion of a curved shape (similar to a football).
 */

import acm.program.*;

import java.awt.event.*;

import acm.graphics.*;

public class MyLineArt extends GraphicsProgram {
	public void run() {
		// TODO
	}
}
