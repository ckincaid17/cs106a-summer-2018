import acm.program.*;

public class Aquarium extends Program {
	public void run() {
		FishTank tank = new FishTank();
		add(tank);
		tank.initialize();
		tank.addFish(5);

		while (true) {
			tank.moveFish();
			pause(30);
		}
	}
}
