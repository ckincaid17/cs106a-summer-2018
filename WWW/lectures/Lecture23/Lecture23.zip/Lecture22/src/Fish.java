import acm.graphics.*;
import acm.util.*;

public class Fish {
	
	// How much a fish moves each "swim"
	private static final int MOVE_AMOUNT = 5;
	
	// Instance variables
	private GImage image;
	private double goalX;
	private double goalY;
	
	public Fish(int maxX, int maxY) {
		image = new GImage("res/blueFishRight.png");

		// Randomize initial location
		double x = RandomGenerator.getInstance().nextDouble(0, maxX - image.getWidth());
		double y = RandomGenerator.getInstance().nextDouble(0, maxY - image.getHeight());
		image.setLocation(x, y);
		
		pickNewGoal(maxX, maxY);
	}
	
	private void pickNewGoal(int maxX, int maxY) {
		goalX = RandomGenerator.getInstance().nextDouble(0, maxX - image.getWidth());
		goalY = RandomGenerator.getInstance().nextDouble(0, maxY - image.getHeight());
		
		if (image.getX() > goalX) {
			image.setImage("res/blueFishLeft.png");
		} else {
			image.setImage("res/blueFishRight.png");
		}
	}
	
	public GImage getImage() {
		return image;
	}
	
	public void swim(int maxX, int maxY) {
		swimTowardsGoal();
		
		if (image.getX() == goalX && image.getY() == goalY) {
			pickNewGoal(maxX, maxY);
		}
	}
	
	private void swimTowardsGoal() {
		double dy = goalY - image.getY();
		double dx = goalX - image.getX();
		double dist = Math.sqrt(dx * dx + dy * dy);
		if(dist > MOVE_AMOUNT) {
			// move MOVE_AMT pixels towards the goal
			double moveX = MOVE_AMOUNT / dist * dx;
			double moveY = MOVE_AMOUNT / dist * dy;
			image.move(moveX, moveY);
		} else {
			image.setLocation(goalX, goalY);
		}
	}
}
