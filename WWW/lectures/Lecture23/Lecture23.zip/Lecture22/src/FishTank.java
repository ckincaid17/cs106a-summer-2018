import acm.graphics.*;
import java.util.*;

public class FishTank extends GCanvas {
	private ArrayList<Fish> fish;
	
	public FishTank() {
		fish = new ArrayList<>();
	}
	
	public void initialize() {
		GImage background = new GImage("res/background.jpg");
		background.setSize(getWidth(), getHeight());
		add(background);
	}
	
	public void addFish(int numFish) {
		for (int i = 0; i < numFish; i++) {
			Fish newFish = new Fish(getWidth(), getHeight());
			fish.add(newFish);
			add(newFish.getImage());
		}
	}
	
	public void moveFish() {
		for (Fish currentFish : fish) {
			currentFish.swim(getWidth(), getHeight());
		}
	}
}
