/* File: MyTipCalculator.java
 * ------------------------
 * This program demonstrates using interactors
 * to let a user calculate a tip for their bill.
 */
import javax.swing.*;
import acm.program.*;
import java.awt.event.*;

public class MyTipCalculator extends ConsoleProgram {
	
	private static final int TEXT_FIELD_WIDTH = 10;
	
	// Add instance variables

	public void init() {
		// Add interactors
	}
	
	public void actionPerformed(ActionEvent event) {
		clearConsole();
		
		// Get subtotal from text field
		
		// Calculate tip using percentage user wants
		
		// Print subtotal, tip, total
	}
}
