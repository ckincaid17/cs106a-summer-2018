
import java.awt.event.ActionEvent;
import java.util.*;

import javax.swing.*;

import acm.program.*;

public class BouncingBalls extends GraphicsProgram {

	private static final int DELAY = 3;
	
	private ArrayList<Ball> balls = new ArrayList<Ball>();
		
	public void init() {
		// your code here
	}
	
	public void run() {
		// your code here
	}
	
	public void actionPerformed(ActionEvent e) {
		// your code here
	}

}