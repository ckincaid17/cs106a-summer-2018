import acm.graphics.*;
import acm.program.*;
import acm.util.*;
import java.util.*;
import java.io.*;

public class PhoneBook extends ConsoleProgram {
	
	public void run() {
		setFont("Courier-24");
		HashMap<String, Integer> phoneBook = 
				new HashMap<String, Integer>();
		
		phoneBook.put("Chris", 8666586);
		
		
	}
	
	/*while(true) {
	String cmd = readLine("Enter command (printAll, add, lookup): ");
	if(cmd.equals("printAll")) {
		printMap(phoneBook);
	}
	if(cmd.equals("add")){
		addToMap(phoneBook);
	}
	if(cmd.equals("lookup")){
		lookup(phoneBook);
	}
	println(""); */
	
}
